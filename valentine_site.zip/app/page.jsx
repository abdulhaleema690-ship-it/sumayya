'use client';
import { motion } from "framer-motion";
import { Heart } from "lucide-react";

export default function Page() {
  return (
    <div style={{minHeight:'100vh',display:'flex',justifyContent:'center',alignItems:'center',
      background:'linear-gradient(135deg,#fbcfe8,#fda4af,#fecdd3)',padding:'16px'}}>
      <motion.div initial={{opacity:0,scale:0.9}} animate={{opacity:1,scale:1}} transition={{duration:0.8}}
        style={{maxWidth:'700px',background:'rgba(255,255,255,0.85)',borderRadius:'24px',
        padding:'32px',boxShadow:'0 20px 40px rgba(0,0,0,0.15)'}}>

        <motion.div animate={{scale:[1,1.15,1]}} transition={{repeat:Infinity,duration:1.6}}
          style={{display:'flex',justifyContent:'center'}}>
          <Heart size={64} color="#e11d48" fill="#e11d48"/>
        </motion.div>

        <h1 style={{textAlign:'center',color:'#be123c'}}>For My Kidaw, Sumayya ❤️</h1>
        <p style={{textAlign:'center',fontStyle:'italic',color:'#555'}}>A small apology, written with a full heart</p>

        <div style={{color:'#374151',lineHeight:1.7}}>
          <p><b>My Love ❤️</b></p>
          <p>I’ve been thinking a lot before writing this, because I don’t want to say just “sorry” and end it there.
          You deserve more than that. You deserve to know what’s in my heart—even the things I failed to show you with my time.</p>

          <p>I know I hurt you by not giving you enough time and attention. If my work, tiredness, or silence ever made
          you feel like I don’t care, please forgive me. That was never my intention.</p>

          <p>Even when I’m busy, you are always with me. My love doesn’t disappear when I’m busy—it stays, it waits, and it grows.</p>

          <p>I understand now that love is not only what we feel, but what we show. I failed to show you enough,
          and I take responsibility for that.</p>

          <p>You matter more to me than my schedule, stress, or exhaustion.
          My love for you is real, honest, and deep.</p>

          <p><b style={{color:'#be123c'}}>I love you more than I can explain. And I always will.</b></p>
        </div>

        <div style={{display:'flex',justifyContent:'center',marginTop:'24px'}}>
          <button onClick={()=>alert("Forever starts with us ❤️\n\nThank you for being my Valentine, my Kidaw.")}
            style={{padding:'14px 28px',borderRadius:'999px',border:'none',
            background:'#e11d48',color:'white',fontSize:'18px',cursor:'pointer'}}>
            Be My Valentine 💖
          </button>
        </div>

        <audio autoPlay loop hidden>
          <source src="/love-music.mp3" type="audio/mpeg"/>
        </audio>
      </motion.div>
    </div>
  );
}
